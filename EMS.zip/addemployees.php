<?php
function authentication()
{
if($_POST){
$host="localhost";
$user="root";
$pass="";
$db="midterm";


$id= $_POST['eid'];
$ename= $_POST['name'];
$sal= $_POST['salary'];
$dep= $_POST['department'];
$mail= $_POST['email'];
$pos= $_POST['position'];
$cont= $_POST['contact'];

$conn = mysqli_connect($host,$user,$pass,$db);
$qry="INSERT into einfo (E_ID,Name,Salary,Department,Email,Position,Contact)
        values('$id','$ename','$sal','$dep','$mail','$pos','$cont')";

if(mysqli_query($conn,$qry))
{
    echo "<script> alert('new record inserted');</script>";
    echo "<script> window.open('dashboard.php','_self');</script>";
}
else
{
    echo "error:.mysqli_error($conn)";
}
mysqli_close($conn);
}
}
?>

        <body>
        <link rel="stylesheet" type="text/css" href="new.css">
            <title>Add Employee info </title>
        <?php authentication(); ?>
        <div class=container>
            <form method="post" action="">
                <h2>Employee Register</h2><br>
                <table  cellpadding ="3" cellspacing="0" width="50%">
                <tr>
                    <td>E_ID</td>
                    <td><input type="text" name="eid"> </td>
                </tr> 

                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name"> </td>
                </tr> 

                <tr>
                    <td>Salary</td>
                    <td><input type="text" name="salary"> </td>
                </tr>

                <tr>
                    <td>Department</td>
                    <td><input type="text" name="department"> </td>
                </tr>

                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email"> </td>
                </tr>

                <tr>
                    <td>Position</td>
                    <td><input type="text" name="position"> </td>
                </tr>

                <tr>
                    <td>Contact Number</td>
                    <td><input type="text" name="contact"> </td>
                </tr>   
            </table>
            <center>
            <input type="Submit" value="Submit" class="btn">
            </center>
            </form>
            

        </div>
        </body>
 