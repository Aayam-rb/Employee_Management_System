<?php
function authentication()
{
    if($_POST){
        $host="localhost";
        $user="root";
        $pass="";
        $db="midterm";
        
        $id= $_POST['eid'];
        $ename= $_POST['name'];
        $sal= $_POST['salary'];
       
    $conn = mysqli_connect($host,$user,$pass,$db);
    $qry ="UPDATE einfo SET Salary='$sal' WHERE E_ID='$id' AND Name='$ename'";
    if(mysqli_query($conn,$qry))
    {
        echo"<script> alert('record updated');</script>";
        echo "<script> window.open('Dashboard.php', '_self');</script>";
    }
    else
    {
        echo "error:.mysqli_error($conn)";
    }
    mysqli_close($conn);
        }
}
?>
        <body>
        <link rel="stylesheet" type="text/css" href="new.css">
            <title>Update</title>
        <?php authentication(); ?>
        <div class=container>
            <form method="POST" action="">
                <h2>Update Employees Info</h2><br>
                <table  cellpadding ="3" cellspacing="0" width="50%">
                <tr>
                    <td>E_ID</td>
                    <td><input type="text" name="eid"> </td>
                </tr> 

                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name"> </td>
                </tr> 

                <tr>
                    <td>Salary</td>
                    <td><input type="text" name="salary"> </td>
                </tr>

            </table>
            <center>
            <input type="Submit" value="Submit" class="btn">
            </center>
            </form>
           
</div>
        </body>
