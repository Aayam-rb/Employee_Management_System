<?php
function authencation()
{
if($_POST){
$host="localhost";
$user="root";
$pass="";
$db="midterm";

$uname = $_POST['username'];
$pw = $_POST['password'];

$conn = mysqli_connect($host,$user,$pass,$db);
$qry="select * from login where username='$uname' and password='$pw'";

$result = mysqli_query($conn,$qry);

if(mysqli_num_rows($result)==1){
session_start();
$_SESSION['auth']='true';
header('location:dashboard.php');
}
else{
     echo "<script> alert('wrong username or password'); </script>";
}
}
}
?>
    <link rel="stylesheet" type="text/css" href="style.css">
    <body>
        <title>login page</title>
    <?php authencation(); ?>
        <br>
        <h1>Login page</h1>
        <div class="card">
            <h2 style="color: rgb(255, 243, 239);">Sign In</h2><br>
            <form method="post" action="">
                <input type="text" placeholder="Username" name="username"><br><br>
                <input type="password" placeholder="Password" name="password"><br><br>
                <table border="1px" cellpadding="5px" cellspacing="0px"> 
                <br><br>
                <input type="submit" value="Log in" class="color">
            </form>
        </div>
    </body>




