<?php
session_start();
if(!$_SESSION['auth']){
header('location:login.php');
}
// Connect to your database
$host="localhost";
$user="root";
$pass="";
$db="midterm";
$conn = mysqli_connect($host,$user,$pass,$db);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to fetch employee information
$sql = "SELECT * FROM einfo";


if (isset($_POST['submit'])){
    
    $see=$_POST['search'];
    if ($see){
        $sql="SELECT * from einfo where E_ID='$see'";
        
    }else{
        echo "<script>alert('no data found');</script>";
    }
    
}
$result = mysqli_query($conn, $sql);
?>

<html>
    <head>
        <title>Dashboard</title>
        <link rel="stylesheet" type="text/css" href="dash.css">
        <body>    
        <div class= c style="backgroundcolor:plum">
            <from method="post" action="">
                <img src= "admin.png" style="width:30px">Administrator
                <input type="button" value="Log out" class="bot" onclick="window.open('login.php','_self')">
                </form>
            </div>     
        <div class=container>
            <br>
             
            <div>
                <form method="post" action="">
                    <input type= "text" placeholder="Search E_ID" name="search" class="sch">
                    <input type="submit" name="submit" value="Search" class="btn">    

                    <div class="b">
                        <input type="button" value="Dashboard" class="btn" onclick="window.open('dashboard.php','_self')">
                        <input type="button" value="Add Employees" class="btn" onclick="window.open('addemployees.php','_self')">
                        <input type="button" value="Update" class="btn" onclick="window.open('update.php','_self')">
                        <input type="button" value="Delete" class="btn" onclick="window.open('delete.php','_self')"> 
                    </div>
             </div>
                 
            <h1>Employee Information</h1>
            <table  id="tb" border="1px" cellpadding="5px" cellspacing="0px">
                <tr style="background-color:5a9ecb">
                    <th>E_ID</th>
                    <th>Name</th>
                    <th>Salary</th>
                    <th>Department</th>
                    <th>Email</th>
                    <th>Position</th>
                    <th>Contact Number</th>
                    <hr ><br>
                </tr>
            
                <?php
                // Fetch data from the result set and output it
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$row['E_ID']."</td>";
                    echo "<td>".$row['Name']."</td>";
                    echo "<td>".$row['Salary']."</td>";
                    echo "<td>".$row['Department']."</td>";
                    echo "<td>".$row['Email']."</td>";
                    echo "<td>".$row['Position']."</td>";
                    echo "<td>".$row['Contact']."</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>

</script>
        </body>  
    </head>
</html>
