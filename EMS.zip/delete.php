<?php
function authentication()
{
if($_POST){
$host="localhost";
$user="root";
$pass="";
$db="midterm";
    $id= $_POST['eid'];
   
$conn = mysqli_connect($host,$user,$pass,$db);
$qry ="DELETE FROM einfo WHERE E_ID='$id'";

if(mysqli_query($conn,$qry)) 
{
    if(mysqli_affected_rows($conn) > 0) {
        echo "<script>alert('Record deleted');</script>";
        echo "<script>window.open('dashboard.php', '_self');</script>";
    } else {
        echo "<script> alert( 'No record with E_ID = 1 not found.');</script>";
        echo "<script>window.open('dashboard.php', '_self');</script>";
    }
 
}
else
{
    echo "error:.mysqli_error($conn)";
}
mysqli_close($conn);
}
}
?>
        <body>
        <link rel="stylesheet" type="text/css" href="new.css">
            <title>Delete</title>
        <?php authentication(); ?>
        <div class=container>
            <form method="post" action="">
                <h2>Delete Employees Info</h2><br>
                <table  cellpadding ="3" cellspacing="0" width="50%">
                <tr>
                    <td>E_ID</td>
                    <td><input type="text" name="eid"> </td>
                </tr> 
            </table>
            <center>
            <input type="Submit" value="Submit" class="btn">
            </center>
            </form>
            
</div>

        </body>
